#pragma once

#include <stdint.h>

int64_t reproc_now(void);
