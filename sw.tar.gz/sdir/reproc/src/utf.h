#pragma once

#include <wchar.h>

wchar_t *utf16_from_utf8(const char *string, size_t size);
